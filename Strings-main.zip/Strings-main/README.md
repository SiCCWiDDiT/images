# Strings
FxSound translation strings

To translate FxSound application strings to a new lanuage, copy the file FxSound.txt to FxSound.<language code>.txt. Edit the new file and add the translated strings to the right.

For new translations and translation error fixes, please use the "translation" branch and create a pull request.
